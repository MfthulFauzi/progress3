public class Maps {
    private String name;
    public boolean isfinished;

    Maps(String name){
        this.name = name;
    }


    public boolean isIsfinished() {
        return isfinished;
    }

    public void setIsfinished(boolean isfinished) {
        this.isfinished = isfinished;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
